<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/images/fav.png')); ?>">

        <!-- plugin css -->
        <link href="<?php echo e(asset('assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- App css -->
        <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
        <link href="<?php echo e(asset('assets/libs/bootstrap-table/bootstrap-table.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/libs/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-default-stylesheet" />
        <link href="<?php echo e(asset('assets/css/bootstrap-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" />
        <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="app-dark-stylesheet" />

        <!-- icons -->
        <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <style type="text/css">
            .badge-accepted {
              background-color: #000000;
            }
            .text-large {
              font-size: 90%;
            }
        </style>

    </head>

    <body class="loading">

        <!-- Begin page -->
        <div id="wrapper">

          

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <!-- <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Bus Book</a></li>
                                            <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title"><?php echo $__env->yieldContent('title'); ?></h4>
                                </div>
                            </div>
                        </div>      -->
                        <!-- end page title --> 

                        <?php echo $__env->yieldContent('content'); ?>

                    </div> <!-- container -->

                </div> <!-- content -->

                <!-- Footer Start -->
                
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <!-- Right Sidebar -->
        
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- Vendor js -->
        <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>

        <!-- Plugins js-->
        <script src="<?php echo e(asset('assets/libs/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/select2/js/select2.min.js')); ?>" ></script>
        
        

        <!-- Dashboard 2 init -->
        

        <!-- App js-->
        <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
        


      <?php echo $__env->yieldPushContent('scripts'); ?>
      
        
    </body>
</html><?php /**PATH F:\software\xampp\htdocs\bb\busbook\resources\views/layouts/master-auth.blade.php ENDPATH**/ ?>