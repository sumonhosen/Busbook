<!-- Topbar Start -->
<div class="navbar-custom">
  <div class="container-fluid">
      <ul class="list-unstyled topnav-menu float-right mb-0">

          

          <li class="dropdown d-inline-block d-lg-none">
              <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                  <i class="fe-search noti-icon"></i>
              </a>
              <div class="dropdown-menu dropdown-lg dropdown-menu-right p-0">
                  <form class="p-3">
                      <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                  </form>
              </div>
          </li>

          <li class="dropdown d-none d-lg-inline-block">
              <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="fullscreen" href="#">
                  <i class="fe-maximize noti-icon"></i>
              </a>
          </li>

          <li class="dropdown notification-list topbar-dropdown">
              <a class="nav-link dropdown-toggle waves-effect waves-light"  href="<?php echo e(url('notifications/unread')); ?>" role="button" aria-haspopup="false" aria-expanded="false">
                  <i class="fe-bell noti-icon" id="NotificationBell"></i>
                  <span id="NotificationNumbers" class="badge badge-danger rounded-circle noti-icon-badge">0</span>
              </a>
            
          </li>

          <li class="dropdown notification-list topbar-dropdown">
              <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                  
                  

                  
              </a>
              <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                  <!-- item-->
                  

                  <!-- item-->
                  <a href="<?php echo e(url('password/change')); ?>" class="dropdown-item notify-item">
                      <i class="fe-user"></i>
                      <span>Password Change</span>
                  </a>

                  

                  <div class="dropdown-divider"></div>

                  <!-- item-->
                  <form  action="<?php echo e(url('logout')); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <button type="submit"  class="dropdown-item notify-item">
                          <i class="fe-log-out"></i>
                          <span>Logout</span>
                      </button>
                  </form>

              </div>
          </li>
         

      </ul>

      <!-- LOGO -->
      

      <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
          <li>
              <button class="button-menu-mobile waves-effect waves-light">
                  <i class="fe-menu"></i>
              </button>
          </li>

          <li>
              <!-- Mobile menu toggle (Horizontal Layout)-->
              <a class="navbar-toggle nav-link" data-toggle="collapse" data-target="#topnav-menu-content">
                  <div class="lines">
                      <span></span>
                      <span></span>
                      <span></span>
                  </div>
              </a>
              <!-- End mobile menu toggle-->
          </li>   

          <li class="dropdown d-none d-xl-block">
             
          </li>

          <li class="dropdown dropdown-mega d-none d-xl-block">
              
          </li>
      </ul>
      <div class="clearfix"></div>
  </div>
</div>
<!-- end Topbar<?php /**PATH F:\software\xampp\htdocs\bb\busbook\resources\views/partials/topbar.blade.php ENDPATH**/ ?>